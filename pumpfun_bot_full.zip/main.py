import requests
import time
import subprocess
import tweepy
import json
from telegram import Bot
from keep_alive import keep_alive

# === Token & Wallet File ===
TWITTER_BEARER_TOKEN = "AAAABBB..."  # Ganti dengan tokenmu
TELEGRAM_BOT_TOKEN = "6181036122:AAFy..."  # Sudah dimasukkan sesuai permintaan
TELEGRAM_CHAT_ID = "7806614019"  # Sudah dimasukkan sesuai permintaan
KEYPAIR_FILE = "my-autobuy-wallet.json"

# === Konfigurasi Bot ===
INITIAL_BUY = 0.03
TOPUP_BUY = 0.07
MIN_MINTER = 8
TOPUP_MINTER = 25
KEYWORDS = ["doge", "elon", "pepe", "moon", "baby"]
CHECK_INTERVAL = 10
TRAILING_STOP = 0.35

last_token_id = None
bought_tokens = {}
bot = Bot(token=TELEGRAM_BOT_TOKEN)
keep_alive()

def kirim_pesan(text):
    try:
        bot.send_message(chat_id=TELEGRAM_CHAT_ID, text=text)
    except Exception as e:
        print(f"Gagal kirim pesan: {e}")

def get_latest_token():
    try:
        res = requests.get("https://pump.fun/api/tokens?limit=1")
        return res.json()[0]
    except:
        return None

def beli_token(token_id, jumlah):
    subprocess.run(["./pumpfun-bot", "--keypair", KEYPAIR_FILE, "--amount", str(jumlah), "--token", token_id])

print("[BOT AKTIF] Pantau Pump.fun + Twitter + Telegram + Trailing Stop")

while True:
    token = get_latest_token()
    if not token:
        time.sleep(CHECK_INTERVAL)
        continue

    token_id = token["id"]
    token_name = token["name"].lower()
    minter_count = token.get("minterCount", 0)

    # Beli awal
    if token_id != last_token_id and minter_count >= MIN_MINTER and any(k in token_name for k in KEYWORDS):
        print(f"\n🔥 Token Baru Cocok: {token['name']}")
        kirim_pesan(f"[Beli Awal] {token['name']} cocok dengan keyword. Beli {INITIAL_BUY} SOL.")
        beli_token(token_id, INITIAL_BUY)
        bought_tokens[token_id] = {"top": INITIAL_BUY, "price": token["price"]}
        last_token_id = token_id

    # Top-up jika trending Twitter
    elif minter_count >= TOPUP_MINTER and token_id in bought_tokens:
        mentioned_on_twitter = any(k in token_name for k in KEYWORDS)
        if mentioned_on_twitter:
            print(f"[TOP-UP] {token_name} trending di Twitter. Top-up {TOPUP_BUY} SOL.")
            kirim_pesan(f"[TOP-UP] {token_name} trending di Twitter. Top-up {TOPUP_BUY} SOL.")
            beli_token(token_id, TOPUP_BUY)
            bought_tokens[token_id]["top"] += TOPUP_BUY

    # Trailing Stop
    if token_id in bought_tokens:
        top = bought_tokens[token_id]["top"]
        now_price = token["price"]
        if now_price <= (1 - TRAILING_STOP) * top:
            print(f"[CUT LOSS] {token_name} turun 35%. Jual sekarang.")
            kirim_pesan(f"[CUT LOSS] {token_name} turun 35%. Jual sekarang.")
            subprocess.run(["./pumpfun-sell", "--keypair", KEYPAIR_FILE, "--token", token_id])
            del bought_tokens[token_id]

    time.sleep(CHECK_INTERVAL)
